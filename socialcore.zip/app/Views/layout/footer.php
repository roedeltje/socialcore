</main>

<hr>
<footer>
    <p>&copy; <?= date('Y') ?> SocialCore. Alle rechten voorbehouden.</p>
</footer>

</body>
</html>
